By_ Shahin Noursalehi
Contact: admin@MixofTix.net

This is a simple application, demonstrates using TCP protocol
for data communications...

The sample is useful for beginners in VB...!
