By_ Shahin Noursalehi
Contact: admin@MixofTix.net

This is a simple application, demonstrates using UDP protocol
for data communications...

The sample is useful for beginners in VB...!
